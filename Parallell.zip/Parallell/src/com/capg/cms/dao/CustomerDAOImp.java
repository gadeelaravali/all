package com.capg.cms.dao;
import java.util.HashMap;
import java.util.Iterator;
/*import java.util.List;
import java.util.ArrayList;*/
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capg.cms.beans.Customer;
import com.capg.cms.exception.CustomerNotFound;
//import com.capgemini.jpa.utility.JPAUtil;
public class CustomerDAOImp implements ICustomerDAO {
	Map<Integer,Customer> custList=new HashMap<Integer,Customer>();		
	Map<Integer,StringBuffer> transaction=new HashMap<Integer,StringBuffer>();
	//Customer a=new Customer(null,null,0,null,0,null);
	//static List<Customer> custList = new ArrayList<Customer>();
	//private EntityManager entityManager=null;
	//EntityManagerFactory factory = Persistence.createEntityManagerFactory("Parallell"); 
	@Override
	public boolean addCustomer(Customer cus) throws CustomerNotFound{
		EntityManager em=Persistence.createEntityManagerFactory("Parallell").createEntityManager();
			try{
				
				em.getTransaction().begin();
				
				em.persist(cus);
				em.getTransaction().commit();
				return em.contains(cus);
			}catch(PersistenceException e) {
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}finally {    
				em.close();
			}
	}

	/*EntityManagerFactory factory=Persistence.createEntityManagerFactory("Parallell");
	
	@Override
	public boolean addCustomer(Customer c) throws CustomerNotFound {
		EntityManager em=factory.createEntityManager();
		try{
		
			em.getTransaction().begin();
		
			em.persist(c);
			em.getTransaction().commit();	
		return	em.contains(c);
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		//return false;
		 * 
*/		
	/*	
	int key=c.getAccno();
	custList.put(key,c);
	return custList.containsValue(c);*/	
	
	@Override
	public boolean validateAccno(int id1) throws CustomerNotFound {
		EntityManager em=Persistence.createEntityManagerFactory("Parallell").createEntityManager();
	boolean flag=false;
		try{
	Customer customer=em.find(Customer.class, id1);
		if(customer.getAccno()==id1)
		{
			flag=true;
		}
			return flag;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		
	/*boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getAccno()==id1))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;*/
	}
	@Override
	public boolean validatePinno(int pinno) throws CustomerNotFound {
/*	boolean flag=false;
		for (Customer c:custList.values()) {
			if((c.getPin()==id2))
	//	if(ca.getAccno()==accno)
		flag=true;
		}
		return flag;*/
		EntityManager em=Persistence.createEntityManagerFactory("Parallell").createEntityManager();
		boolean flag=false;
			try{
		Customer customer=em.find(Customer.class, pinno);
			if(customer.getPin()==pinno)
			{
				flag=true;
			}
				return flag;
			}catch(PersistenceException e) {
				e.printStackTrace();
				//TODO: Log to file
				throw new CustomerNotFound(e.getMessage());
			}finally {
				em.close();
			}
	
	}
	
	public Customer displayCustomer(int id1,int id2) throws CustomerNotFound {	
/*	Customer cust=null;
	for(Customer c:custList.values())
	{
		if((c.getAccno()==id1)&&(c.getPin()==id2))
		{
		System.out.println("Balance is:"+c.getAmt());	
		}
	}
	return cust;*/
		
		EntityManager em=Persistence.createEntityManagerFactory("Parallell").createEntityManager();
		try{
			
			Customer customer=em.find(Customer.class, id1);
			System.out.println("Balance is:"+customer.getAmt());	
			return customer;
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		
		
		
	
	}
	public Customer withDraw(Customer c1,int wd) throws CustomerNotFound {
	
	/*	Customer cust=null;
		for(Customer c:custList.values())
		{			
		if((c.getAmt()>wd))
		{
		int bal=0;
		bal=c.getAmt()-wd;
		c.setAmt(bal);
		System.out.println("balance is"+c.getAmt());
		}
		}			
		return cust;*/
		EntityManager em=Persistence.createEntityManagerFactory("Parallell").createEntityManager();
		try{
		
			em.getTransaction().begin();
		
			em.getTransaction().commit();			
		}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally {
			em.close();
		}
		return c1;
		
	}
	public int depositAmt(int da,Customer c) {
		// TODO Auto-generated method stub		
		int bal=0;
		bal=c.getAmt()+da;          
		c.setAmt(bal);
		System.out.println("balance is"+c.getAmt());
		System.out.println("deposit done successfully");			
		return c.getAmt();
	}
	@Override
	public Customer printTransactions(int cid,int pinno) {
		// TODO Auto-generated method stub
	for(StringBuffer trans:transaction.values())
	{
		if(transaction.containsKey(cid))
	{
			Object trns=transaction.get(cid);

		System.out.println("acc no:"+cid+"\n"+trns+"\n");
	}
	}
		return null;
	}
	

	public Customer printTransaction(Customer cid) {
		// TODO Auto-generated method stub
		Customer cust=null;
		int acc=cid.getAccno();
		StringBuffer s= new StringBuffer();
		s=cid.getSb();	
		s.append("balance:\n");
		s.append(cid.getAmt());
		System.out.println(cid.getAmt());
	
		cid.setSb(s);
		transaction.put(acc,s);
		for(StringBuffer transaction1:transaction.values())
		{
		transaction.entrySet().stream().forEach(System.out::println);	
		System.out.println("transaction");
		}
		
		return cust;
	}
	

	public Customer displayCust(int accno) {
		// TODO Auto-generated method stub
		Customer cust=null;
		for (Customer c:custList.values()) {
			if(c.getAccno()==accno)
					{
				cust=c;
					}
		}return cust;
	}
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno)
	{
		boolean flag=false;	
			if((c.getAccno()==accno1) && (c.getPin()==pinno))
			{
				if(b.getAccno()==accno2)
				{
					if((c.getAmt()>amt))
					{
					int bal=0;
					int bal1=0;
					bal=c.getAmt()-amt;
					bal1=b.getAmt()+amt;
					c.setAmt(bal);
					b.setAmt(bal1);
					flag=true;
					}
				}
			
		}
	return flag;
}
}

