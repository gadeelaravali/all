package com.capg.cms.service;

import com.capg.cms.beans.Customer;

public interface ICustomerService {

	
   public boolean addCustomer(Customer c);
  public Customer displayCustomer(int accno,int pinno); 
  public Customer displayCust(int accno);
   public	Customer withDraw(Customer c1,int wd);
   public int depositAmt(int da,Customer c);
   public Customer printTransaction(Customer c) ; 

	public boolean validateAccno(int accno);
	public boolean validatePinno(int pinno);
	public boolean fundTransfer(Customer c,Customer b,int amt,int accno1,int accno2,int pinno);
	
	public Customer printTransactions(int cid,int pinno);
	
	
}
