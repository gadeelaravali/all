package com.fms.service;

import com.fms.bean.FlightBean;

public interface IFlightService {

	public int addFlightDetails(FlightBean f);
	
	
}
