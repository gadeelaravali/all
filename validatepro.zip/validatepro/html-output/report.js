$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("featuresfile/vali.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    }
  ],
  "line": 4,
  "name": "validation for html file",
  "description": "",
  "id": "validation-for-html-file",
  "keyword": "Feature",
  "tags": [
    {
      "line": 3,
      "name": "@tag"
    }
  ]
});
formatter.before({
  "duration": 4989922039,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 9,
  "name": "checking username",
  "description": "",
  "id": "validation-for-html-file;checking-username",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 8,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 10,
  "name": "empty value is entered in user text box",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "print error message for username field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.empty_value_is_entered_in_user_text_box()"
});
formatter.result({
  "duration": 247695894,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_username_field()"
});
formatter.result({
  "duration": 4141123866,
  "status": "passed"
});
formatter.before({
  "duration": 4351416227,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 13,
  "name": "checking city",
  "description": "",
  "id": "validation-for-html-file;checking-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 268727305,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 4117237478,
  "status": "passed"
});
formatter.before({
  "duration": 4308651046,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 18,
  "name": "checking password",
  "description": "",
  "id": "validation-for-html-file;checking-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "empty value is entered in  password text box",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.empty_value_is_entered_in_password_text_box()"
});
formatter.result({
  "duration": 308622329,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4139988275,
  "status": "passed"
});
formatter.before({
  "duration": 4256831495,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 23,
  "name": "checking gender",
  "description": "",
  "id": "validation-for-html-file;checking-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "enter empty value in gender radio button",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "print error message for gender field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_gender_radio_button()"
});
formatter.result({
  "duration": 383360061,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_gender_field()"
});
formatter.result({
  "duration": 4125066410,
  "status": "passed"
});
formatter.before({
  "duration": 4237363164,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 28,
  "name": "checking known languages",
  "description": "",
  "id": "validation-for-html-file;checking-known-languages",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "enter empty value in checking languages",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "print error message for languages field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_checking_languages()"
});
formatter.result({
  "duration": 402291366,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_languages_field()"
});
formatter.result({
  "duration": 4111740855,
  "status": "passed"
});
formatter.before({
  "duration": 4287840355,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 33,
  "name": "checking mynumber",
  "description": "",
  "id": "validation-for-html-file;checking-mynumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "enter empty value in mynumber field",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print error message for mynumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_mynumber_field()"
});
formatter.result({
  "duration": 561130537,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_mynumber_field()"
});
formatter.result({
  "duration": 4121633381,
  "status": "passed"
});
formatter.before({
  "duration": 4417462668,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 38,
  "name": "checking email",
  "description": "",
  "id": "validation-for-html-file;checking-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "enter empty value in email field",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "print error message for email field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_email_field()"
});
formatter.result({
  "duration": 694352445,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_email_field()"
});
formatter.result({
  "duration": 4132921189,
  "status": "passed"
});
formatter.before({
  "duration": 4510432628,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 43,
  "name": "checking mobile",
  "description": "",
  "id": "validation-for-html-file;checking-mobile",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "enter empty value in mobilenumber field",
  "keyword": "When "
});
formatter.step({
  "line": 46,
  "name": "print error message for mobilenumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.enter_empty_value_in_mobilenumber_field()"
});
formatter.result({
  "duration": 749044614,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.print_error_message_for_mobilenumber_field()"
});
formatter.result({
  "duration": 4133180471,
  "status": "passed"
});
formatter.before({
  "duration": 4417735899,
  "status": "passed"
});
formatter.background({
  "line": 6,
  "name": "Given check the value given",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.scenario({
  "line": 48,
  "name": "all details entered",
  "description": "",
  "id": "validation-for-html-file;all-details-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "all the details enteres successfully",
  "keyword": "When "
});
formatter.step({
  "line": 51,
  "name": "return successfull page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefi.all_the_details_enteres_successfully()"
});
formatter.result({
  "duration": 896518437,
  "status": "passed"
});
formatter.match({
  "location": "StepDefi.return_successfull_page()"
});
formatter.result({
  "duration": 4162967996,
  "status": "passed"
});
});