$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/validation.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: ravali"
    }
  ],
  "line": 4,
  "name": "validation for html file",
  "description": "",
  "id": "validation-for-html-file",
  "keyword": "Feature",
  "tags": [
    {
      "line": 3,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "checking username",
  "description": "",
  "id": "validation-for-html-file;checking-username",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "check username",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "empty value is entered in user text box",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "print error message for username field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_username()"
});
formatter.result({
  "duration": 5891026328,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_user_text_box()"
});
formatter.result({
  "duration": 138389503,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_username_field()"
});
formatter.result({
  "duration": 4125760565,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "checking city",
  "description": "",
  "id": "validation-for-html-file;checking-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "check user cityname",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_cityname()"
});
formatter.result({
  "duration": 4454439124,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 271720949,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 4119612454,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "checking password",
  "description": "",
  "id": "validation-for-html-file;checking-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "check password",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "empty value is entered in  password text box",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_password()"
});
formatter.result({
  "duration": 4386306527,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_password_text_box()"
});
formatter.result({
  "duration": 335065028,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4114547834,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "checking gender",
  "description": "",
  "id": "validation-for-html-file;checking-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "check user gender is entered",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "enter empty value in gender radio button",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "print error message for gender field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_gender_is_entered()"
});
formatter.result({
  "duration": 4657739476,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_gender_radio_button()"
});
formatter.result({
  "duration": 326707273,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_gender_field()"
});
formatter.result({
  "duration": 4125232565,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "checking known languages",
  "description": "",
  "id": "validation-for-html-file;checking-known-languages",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "check user languages is entered",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "enter empty value in checking languages",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "print error message for languages field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_languages_is_entered()"
});
formatter.result({
  "duration": 4491706862,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_checking_languages()"
});
formatter.result({
  "duration": 378964569,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_languages_field()"
});
formatter.result({
  "duration": 4109153775,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "checking mynumber",
  "description": "",
  "id": "validation-for-html-file;checking-mynumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "check user has entered in mynumber field",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "enter empty value in mynumber field",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "print error message for mynumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_mynumber_field()"
});
formatter.result({
  "duration": 4496940919,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_mynumber_field()"
});
formatter.result({
  "duration": 594166885,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_mynumber_field()"
});
formatter.result({
  "duration": 4104347615,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "checking email",
  "description": "",
  "id": "validation-for-html-file;checking-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "check user has entered in email field",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "enter empty value in email field",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "print error message for email field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_email_field()"
});
formatter.result({
  "duration": 4653112189,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_email_field()"
});
formatter.result({
  "duration": 615601988,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_email_field()"
});
formatter.result({
  "duration": 4125657180,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "checking mobile",
  "description": "",
  "id": "validation-for-html-file;checking-mobile",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "check user has entered in mobilenumber field",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "enter empty value in mobilenumber field",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "print error message for mobilenumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_mobilenumber_field()"
});
formatter.result({
  "duration": 4521512027,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_mobilenumber_field()"
});
formatter.result({
  "duration": 704795534,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_mobilenumber_field()"
});
formatter.result({
  "duration": 4124209384,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "all details entered",
  "description": "",
  "id": "validation-for-html-file;all-details-entered",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "check user has entered all fields",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "all the details enteres successfully",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "return successfull page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_all_fields()"
});
formatter.result({
  "duration": 4448806296,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.all_the_details_enteres_successfully()"
});
formatter.result({
  "duration": 783241169,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.return_successfull_page()"
});
formatter.result({
  "duration": 4213481699,
  "status": "passed"
});
});