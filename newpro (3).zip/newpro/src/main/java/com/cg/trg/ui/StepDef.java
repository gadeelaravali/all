package com.cg.trg.ui;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {

	private Customer customer;
	private WebDriver driver;
	@Given("^check username$")
	public void check_username() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user cityname$")
	public void check_user_cityname() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check password$")
	public void check_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user gender is entered$")
	public void check_user_gender_is_entered() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user languages is entered$")
	public void check_user_languages_is_entered() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user has entered in mynumber field$")
	public void check_user_has_entered_in_mynumber_field() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user has entered in email field$")
	public void check_user_has_entered_in_email_field() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user has entered in mobilenumber field$")
	public void check_user_has_entered_in_mobilenumber_field() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@Given("^check user has entered all fields$")
	public void check_user_has_entered_all_fields() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}


	@When("^empty value is entered in user text box$")
	public void empty_value_is_entered_in_user_text_box() throws Throwable {
		customer.setName("");
		customer.setStore();

	}

	@Then("^print error message for username field$")
	public void print_error_message_for_username_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


	
	@When("^enter empty value in city text box$")
	public void enter_empty_value_in_city_text_box() throws Throwable {
		customer.setName("ravali");
		customer.setCity("");
		customer.setStore();
	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


	@When("^empty value is entered in  password text box$")
	public void empty_value_is_entered_in_password_text_box() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("");
		customer.setStore();

	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	

	@When("^enter empty value in gender radio button$")
	public void enter_empty_value_in_gender_radio_button() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		//customer.setFemale();
		customer.setStore();
	}

	@Then("^print error message for gender field$")
	public void print_error_message_for_gender_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


	@When("^enter empty value in checking languages$")
	public void enter_empty_value_in_checking_languages() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setStore();
	}

	@Then("^print error message for languages field$")
	public void print_error_message_for_languages_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

/*	@Given("^check user has entered in hidden field$")
	public void check_user_has_entered_in_hidden_field() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
	}

	@When("^enter empty value in hidden field$")
	public void enter_empty_value_in_hidden_field() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setEng();
		customer.setTel();
		customer.setHidden("");
		customer.setStore();
	}

	@Then("^print error message for hidden field$")
	public void print_error_message_for_hidden_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}*/
	
	@When("^enter empty value in mynumber field$")
	public void enter_empty_value_in_mynumber_field() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setEng();
		customer.setTel();
		//customer.setHidden("this data is hidden");
		customer.setNummber("");
		customer.setStore();
	}

	@Then("^print error message for mynumber field$")
	public void print_error_message_for_mynumber_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();

	}

	
	@When("^enter empty value in email field$")
	public void enter_empty_value_in_email_field() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setEng();
		customer.setTel();
		//customer.setHidden("this data is hidden");
		customer.setNummber("90");
		customer.setEmail("");
		customer.setStore();
	}

	@Then("^print error message for email field$")
	public void print_error_message_for_email_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}


	@When("^enter empty value in mobilenumber field$")
	public void enter_empty_value_in_mobilenumber_field() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setEng();
		customer.setTel();
	//	customer.setHidden("this data is hidden");
		customer.setNummber("90");
		customer.setEmail("ravali@gmail.com");
		customer.setMobile("");
		customer.setStore();
	}

	@Then("^print error message for mobilenumber field$")
	public void print_error_message_for_mobilenumber_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();

	}
	
	@When("^all the details enteres successfully$")
	public void all_the_details_enteres_successfully() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("Ravali8");
		customer.setFemale();
		customer.setEng();
		customer.setTel();
	//	customer.setHidden("this data is hidden");
		customer.setNummber("90");
		customer.setEmail("ravali@gmail.com");
		customer.setMobile("8986598652");
		customer.setStore();
	}

	@Then("^return successfull page$")
	public void return_successfull_page() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/success.html");
		driver.close();

	}
}
