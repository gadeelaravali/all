function chkEmpty(){

	/*if (document.forms.[bank].name.value == "") {alert("Please fill the First Name");}
		else {
	alert(" completed Successfully.");

		}*/

    if( document.forms["form1"]["userName"].value == "" ){
       alert("Username should be entered!");
    
    }
    else  if( document.forms["form1"]["city"].value == "" ){
       alert("city should be entered!");

    }
    else  if( document.forms["form1"]["password"].value == "" ){
        alert("password should be entered!");

     }
    else if( document.forms["form1"]["gender"].value=="")
    	{
    	 alert("gender should be entered!");
    
    	}
    else if(document.getElementById("eng").checked==false && document.getElementById("tel").checked==false && document.getElementById("tam").checked==false)
	{
	 alert("languages should be entered!");

	}
   /* else if( document.from1.hiddentype.value=="")
	{
	 alert("hidden should be entered!");
  

	}*/
    else if( document.forms["form1"]["mynumber"].value=="")
	{
	 alert("mynumber should be entered!");


	}
    else if( document.forms["form1"]["emailname"].value=="")
	{
	 alert("email should be entered!");
 

	}
    else if( document.forms["form1"]["mobile"].value=="")
	{
	 alert("mobile should be entered!");


	}
    else
    	{
    	alert("completed successfully");
    	window.location="success.html";
    
    	}
}

