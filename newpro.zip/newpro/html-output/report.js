$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/validation.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: ravali"
    }
  ],
  "line": 4,
  "name": "validation for html file",
  "description": "",
  "id": "validation-for-html-file",
  "keyword": "Feature",
  "tags": [
    {
      "line": 3,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "checking username",
  "description": "",
  "id": "validation-for-html-file;checking-username",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "check username",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "empty value is entered in user text box",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "print error message for username field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_username()"
});
formatter.result({
  "duration": 5091242779,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_user_text_box()"
});
formatter.result({
  "duration": 143571459,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_username_field()"
});
formatter.result({
  "duration": 4097921762,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "Test city",
  "description": "",
  "id": "validation-for-html-file;test-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "check user cityname",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_cityname()"
});
formatter.result({
  "duration": 4341391190,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 243706967,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 4098297556,
  "status": "passed"
});
formatter.scenario({
  "line": 16,
  "name": "checking password",
  "description": "",
  "id": "validation-for-html-file;checking-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 17,
  "name": "check password",
  "keyword": "Given "
});
formatter.step({
  "line": 18,
  "name": "empty value is entered in  password text box",
  "keyword": "When "
});
formatter.step({
  "line": 19,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_password()"
});
formatter.result({
  "duration": 4291318103,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_password_text_box()"
});
formatter.result({
  "duration": 149107055,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4105365873,
  "status": "passed"
});
});