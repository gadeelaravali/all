package com.cg.trg.ui;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StepDef {

	private Customer customer;
	private WebDriver driver;
	
	@Given("^check username$")
	public void check_username() throws Throwable {
	  
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");	
	}


	@When("^empty value is entered in user text box$")
	public void empty_value_is_entered_in_user_text_box() throws Throwable {
customer.setName("");
customer.setStore();
		
	}

	@Then("^print error message for username field$")
	public void print_error_message_for_username_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	
	
	@Given("^check user cityname$")
	public void check_user_cityname() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");	
	}

	@When("^enter empty value in city text box$")
	public void enter_empty_value_in_city_text_box() throws Throwable {
		customer.setName("ravali");
		customer.setCity("");
		customer.setStore();
	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}

	
	@Given("^check password$")
	public void check_password() throws Throwable {

		System.setProperty("webdriver.chrome.driver", "C:\\D Drive\\softwares\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		customer = new Customer(driver);
		driver.get("file:///C:/D%20Drive/programsspring/newpro/form1.html");
		
	}
	@When("^empty value is entered in  password text box$")
	public void empty_value_is_entered_in_password_text_box() throws Throwable {
		customer.setName("Ravali");
		customer.setCity("Hyderabad");
		customer.setPassword("");
		customer.setStore();
				
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();
	}
	
	
	
	
}
