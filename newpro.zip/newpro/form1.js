function chkEmpty(){

	/*if (document.forms.[bank].name.value == "") {alert("Please fill the First Name");}
		else {
	alert(" completed Successfully.");

		}*/
	
    var name = document.forms["form1"]["userName"].value;
    if( name == "" ){
       alert("Username should be entered!");
       return false;
    }
    var password = document.forms["form1"]["password"].value;
    if( password == "" ){
       alert("password should be entered!");
       return false;
    }
    var city = document.forms["form1"]["city"].value;
    if( city == "" ){
       alert("city should be entered!");
       return false;
    }
}

function showDetails(){
	var name = bank.name.value;
	
}
