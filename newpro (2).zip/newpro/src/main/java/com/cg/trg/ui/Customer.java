package com.cg.trg.ui;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Customer {

	WebDriver wd;


	public Customer(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
	
	@FindBy(how=How.NAME,using="userName")
	@CacheLookup
	WebElement name;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME,using="password")
	@CacheLookup
	WebElement password;
	
	/*@FindBy(how=How.NAME,using="gender")
	@CacheLookup
	WebElement gender;
	*/
	@FindBy(xpath="/html/body/form/input[5]")
	@CacheLookup
	WebElement male;
	
	@FindBy(xpath="/html/body/form/input[6]")
	@CacheLookup
	WebElement female;
	
	@FindBy(how=How.NAME,using="lang")
	@CacheLookup
	WebElement languages;
	
	@FindBy(how=How.XPATH,using="/html/body/form/textarea")
	@CacheLookup
	WebElement hidden;
	
	@FindBy(how=How.NAME,using="country")
	@CacheLookup
	WebElement country;
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[11]")
	@CacheLookup
	WebElement number;
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[12]")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.NAME,using="mobile")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[7]")
	@CacheLookup
	WebElement Eng;
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[8]")
	@CacheLookup
	WebElement Tel;
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[9]")
	@CacheLookup
	WebElement Tam;
	
	
	@FindBy(how=How.XPATH,using="/html/body/form/input[15]")
	@CacheLookup
	WebElement store;
	

	public WebElement getStore() {
		return store;
	}

	public void setStore() {
		store.click();
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name) {
		this.name.sendKeys(name);
	}

	public WebElement getCity() {
		return city;
	}

	public void setHidden(String hidden) {
		this.hidden.sendKeys(hidden);
	}

	public WebElement getHidden() {
		return hidden;
	}
	
	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);;
	}

	/*public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender.sendKeys(gender);
	}*/

/*	public WebElement getLanguages() {
		return languages;
	}
*/
	public WebElement getMale() {
		return male;
	}

	public void setMale() {
		male.click();
	}

	public WebElement getFemale() {
		return female;
	}

	public void setFemale() {
		female.click();
	}
	
	

	/*public void setLanguages(String languages) {
		this.languages.sendKeys(languages);
	}*/

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getNummber() {
		return number;
	}

	public void setNummber(String number) {
		this.number.sendKeys(number);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);;
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public Customer(WebElement name, WebElement city, WebElement password, WebElement gender,
			WebElement languages, WebElement country, WebElement nummber, WebElement email, WebElement mobile,
			WebElement store) {
		super();
		this.name = name;
		this.city = city;
		this.password = password;
		//this.gender = gender;
	/*	this.languages = languages;*/
		this.country = country;
		this.number = nummber;
		this.email = email;
		this.mobile = mobile;
		this.store = store;
	
	}

	public WebElement getEng() {
		return Eng;
	}

	public void setEng() {
		Eng.click();
	}

	public WebElement getTel() {
		return Tel;
	}

	public void setTel() {
		Tel.click();
	}

	public WebElement getTam() {
		return Tam;
	}

	public void setTam() {
		Tam.click();
	}

	
	
	
	
	
	
	
	
	
}
