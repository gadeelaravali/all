$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/validation.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: ravali"
    }
  ],
  "line": 4,
  "name": "validation for html file",
  "description": "",
  "id": "validation-for-html-file",
  "keyword": "Feature",
  "tags": [
    {
      "line": 3,
      "name": "@tag"
    }
  ]
});
formatter.scenario({
  "line": 7,
  "name": "checking username",
  "description": "",
  "id": "validation-for-html-file;checking-username",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 6,
      "name": "@tag1"
    }
  ]
});
formatter.step({
  "line": 8,
  "name": "check username",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "empty value is entered in user text box",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "print error message for username field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_username()"
});
formatter.result({
  "duration": 5061005203,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_user_text_box()"
});
formatter.result({
  "duration": 153859881,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_username_field()"
});
formatter.result({
  "duration": 4112983524,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": "checking city",
  "description": "",
  "id": "validation-for-html-file;checking-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 13,
  "name": "check user cityname",
  "keyword": "Given "
});
formatter.step({
  "line": 14,
  "name": "enter empty value in city text box",
  "keyword": "When "
});
formatter.step({
  "line": 15,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_cityname()"
});
formatter.result({
  "duration": 4245402968,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_city_text_box()"
});
formatter.result({
  "duration": 212417903,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 4122608151,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "checking password",
  "description": "",
  "id": "validation-for-html-file;checking-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "check password",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "empty value is entered in  password text box",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_password()"
});
formatter.result({
  "duration": 4239738141,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.empty_value_is_entered_in_password_text_box()"
});
formatter.result({
  "duration": 326617017,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4118390710,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "checking gender",
  "description": "",
  "id": "validation-for-html-file;checking-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "check user gender is entered",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "enter empty value in gender radio button",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "print error message for gender field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_gender_is_entered()"
});
formatter.result({
  "duration": 4358797980,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_gender_radio_button()"
});
formatter.result({
  "duration": 341056420,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_gender_field()"
});
formatter.result({
  "duration": 4143632998,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "checking known languages",
  "description": "",
  "id": "validation-for-html-file;checking-known-languages",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "check user languages is entered",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "enter empty value in checking languages",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "print error message for languages field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_languages_is_entered()"
});
formatter.result({
  "duration": 4328952610,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_checking_languages()"
});
formatter.result({
  "duration": 544947953,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_languages_field()"
});
formatter.result({
  "duration": 4122031740,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "filling hidden",
  "description": "",
  "id": "validation-for-html-file;filling-hidden",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 33,
  "name": "check user has entered in hidden field",
  "keyword": "Given "
});
formatter.step({
  "line": 34,
  "name": "enter empty value in hidden field",
  "keyword": "When "
});
formatter.step({
  "line": 35,
  "name": "print error message for hidden field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_hidden_field()"
});
formatter.result({
  "duration": 4347705863,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_hidden_field()"
});
formatter.result({
  "duration": 605909668,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_hidden_field()"
});
formatter.result({
  "duration": 4115475834,
  "status": "passed"
});
formatter.scenario({
  "line": 37,
  "name": "checking mynumber",
  "description": "",
  "id": "validation-for-html-file;checking-mynumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 38,
  "name": "check user has entered in mynumber field",
  "keyword": "Given "
});
formatter.step({
  "line": 39,
  "name": "enter empty value in mynumber field",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "print error message for mynumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_mynumber_field()"
});
formatter.result({
  "duration": 4300239139,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_mynumber_field()"
});
formatter.result({
  "duration": 647050232,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_mynumber_field()"
});
formatter.result({
  "duration": 4113580447,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "checking mynumber",
  "description": "",
  "id": "validation-for-html-file;checking-mynumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "check user has entered in email field",
  "keyword": "Given "
});
formatter.step({
  "line": 44,
  "name": "enter empty value in email field",
  "keyword": "When "
});
formatter.step({
  "line": 45,
  "name": "print error message for email field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_email_field()"
});
formatter.result({
  "duration": 4379671442,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_email_field()"
});
formatter.result({
  "duration": 715557393,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_email_field()"
});
formatter.result({
  "duration": 4123896358,
  "status": "passed"
});
formatter.scenario({
  "line": 47,
  "name": "checking mynumber",
  "description": "",
  "id": "validation-for-html-file;checking-mynumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 48,
  "name": "check user has entered in mobilenumber field",
  "keyword": "Given "
});
formatter.step({
  "line": 49,
  "name": "enter empty value in mobilenumber field",
  "keyword": "When "
});
formatter.step({
  "line": 50,
  "name": "print error message for mobilenumber field",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDef.check_user_has_entered_in_mobilenumber_field()"
});
formatter.result({
  "duration": 4559530124,
  "status": "passed"
});
formatter.match({
  "location": "StepDef.enter_empty_value_in_mobilenumber_field()"
});
formatter.result({
  "duration": 526492545,
  "error_message": "org.openqa.selenium.NoSuchWindowException: no such window: target window already closed\nfrom unknown error: web view not found\n  (Session info: chrome\u003d69.0.3497.100)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.16299 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:32:19.891Z\u0027\nSystem info: host: \u0027CHNSIPDT0T502\u0027, ip: \u002710.219.34.200\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_131\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\ravalg\\AppData\\Loc...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:61844}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 69.0.3497.100, webStorageEnabled: true}\nSession ID: 74191b50f4e909494c2a3e807b453719\n*** Element info: {Using\u003dxpath, value\u003d/html/body/form/textarea}\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:322)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:424)\r\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:314)\r\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\r\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\r\n\tat com.sun.proxy.$Proxy16.sendKeys(Unknown Source)\r\n\tat com.cg.trg.ui.Customer.setHidden(Customer.java:107)\r\n\tat com.cg.trg.ui.StepDef.enter_empty_value_in_mobilenumber_field(StepDef.java:275)\r\n\tat ✽.When enter empty value in mobilenumber field(features/validation.feature:49)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "StepDef.print_error_message_for_mobilenumber_field()"
});
formatter.result({
  "status": "skipped"
});
});